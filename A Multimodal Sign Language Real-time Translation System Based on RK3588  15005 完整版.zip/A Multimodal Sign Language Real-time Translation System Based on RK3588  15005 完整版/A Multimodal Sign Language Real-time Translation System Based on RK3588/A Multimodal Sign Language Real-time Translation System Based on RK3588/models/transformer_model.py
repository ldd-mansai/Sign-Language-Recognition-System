
import math

import torch
import torch.nn as nn


class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super(PositionalEncoding, self).__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        return x + self.pe[:, :x.size(1)]


class TransformerModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_heads, num_layers, num_classes, dropout=0.1):
        super(TransformerModel, self).__init__()

        # 特征嵌入层
        self.embedding = nn.Linear(input_size, hidden_size)

        # 位置编码
        self.pos_encoder = PositionalEncoding(hidden_size)

        # Transformer编码器层
        encoder_layers = nn.TransformerEncoderLayer(
            d_model=hidden_size,
            nhead=num_heads,
            dim_feedforward=hidden_size * 4,
            dropout=dropout,
            batch_first=True
        )
        self.transformer_encoder = nn.TransformerEncoder(encoder_layers, num_layers)

        # 分类器
        self.classifier = nn.Sequential(
            nn.Linear(hidden_size, hidden_size // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_size // 2, num_classes)
        )

    def forward(self, x):
        # x的形状: [batch_size, seq_len, input_size]

        # 特征嵌入
        x = self.embedding(x)

        # 位置编码
        x = self.pos_encoder(x)

        # Transformer编码器
        x = self.transformer_encoder(x)

        # 全局池化 (使用平均池化)
        x = torch.mean(x, dim=1)

        # 分类
        x = self.classifier(x)

        return x

    def get_attention_weights(self, x):
        """获取注意力权重用于可视化"""
        x = self.embedding(x)
        x = self.pos_encoder(x)

        # 获取注意力权重 (简化版本)
        attentions = []
        for layer in self.transformer_encoder.layers:
            x = layer(x)
            # 注：这只是一个近似方法，实际获取注意力权重需要修改PyTorch源码
            attentions.append(x)

        # 返回最后一层的激活作为注意力的近似
        return attentions[-1]
