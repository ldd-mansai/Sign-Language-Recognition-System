

import torch
import torch.nn as nn


class ImprovedBiLSTMModel(nn.Module):
    """改进的双向LSTM模型"""

    def __init__(self, config):
        super(ImprovedBiLSTMModel, self).__init__()
        self.config = config

        # 批归一化层
        self.batch_norm = nn.BatchNorm1d(config.input_size)

        # 特征提取层
        self.feature_extractor = nn.Sequential(
            nn.Linear(config.input_size, config.hidden_size * 2),
            nn.LayerNorm(config.hidden_size * 2),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(config.hidden_size * 2, config.hidden_size),
            nn.LayerNorm(config.hidden_size),
            nn.ReLU(),
            nn.Dropout(0.3)
        )

        # LSTM层
        self.lstm = nn.LSTM(
            config.hidden_size,
            config.hidden_size,
            config.num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=0.3 if config.num_layers > 1 else 0
        )

        # 多头注意力层
        self.multihead_attn = nn.MultiheadAttention(
            config.hidden_size * 2,
            config.num_heads,
            dropout=0.1
        )

        # 残差连接
        self.residual_fc = nn.Linear(config.input_size, config.hidden_size * 2)

        # 分类器
        self.classifier = nn.Sequential(
            nn.Linear(config.hidden_size * 2, config.hidden_size * 2),
            nn.LayerNorm(config.hidden_size * 2),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(config.hidden_size * 2, config.hidden_size),
            nn.LayerNorm(config.hidden_size),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(config.hidden_size, config.num_classes)
        )

    def forward(self, x):
        batch_size, seq_len, input_dim = x.size()

        # 批归一化
        x_reshaped = x.view(-1, input_dim)
        x_normalized = self.batch_norm(x_reshaped)
        x = x_normalized.view(batch_size, seq_len, input_dim)

        # 残差连接
        identity = self.residual_fc(x)

        # 特征提取
        x = x.view(-1, input_dim)
        x = self.feature_extractor(x)
        x = x.view(batch_size, seq_len, -1)

        # LSTM处理
        h0 = torch.zeros(self.config.num_layers * 2, batch_size, self.config.hidden_size).to(x.device)
        c0 = torch.zeros(self.config.num_layers * 2, batch_size, self.config.hidden_size).to(x.device)
        lstm_out, _ = self.lstm(x, (h0, c0))

        # 多头注意力
        attn_output, _ = self.multihead_attn(
            lstm_out.permute(1, 0, 2),
            lstm_out.permute(1, 0, 2),
            lstm_out.permute(1, 0, 2)
        )
        attn_output = attn_output.permute(1, 0, 2)

        # 残差连接
        output = attn_output + identity

        # 全局平均池化
        output = torch.mean(output, dim=1)

        # 分类
        output = self.classifier(output)

        return output
