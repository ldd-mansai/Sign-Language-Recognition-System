

import os
import pickle
import warnings

import cv2
import matplotlib.pyplot as plt
import mediapipe as mp
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset, DataLoader
from torch.utils.data.sampler import WeightedRandomSampler
from tqdm import tqdm
import shutil

# 导入新增模型
from models.transformer_model import TransformerModel
from models.cnn_lstm_model import CNN_LSTM_Model
from models.gru_model import GRUModel
from models.ensemble_model import EnsembleModel

# 导入TensorBoard和指标支持
from utils.tensorboard_logger import TensorboardLogger
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix, classification_report
import seaborn as sns

warnings.filterwarnings('ignore')


# 配置
class Config:
    """配置参数"""

    def __init__(self):
        self.video_dir = 'dataset'  # 视频目录
        self.corpus_file = 'dataset/corpus.txt'  # 语料库文件
        self.model_save_path = 'models/'  # 模型保存目录
        self.feature_cache_dir = 'features/'  # 特征缓存目录
        self.batch_size = 64  # 增大批量大小
        self.learning_rate = 0.001  # 学习率
        self.num_epochs = 100  # 训练轮数
        self.patience = 10  # 早停耐心值
        self.input_size = 42 * 2  # 输入特征维度 (21个手部关键点 x 2手 x 2坐标)
        self.hidden_size = 128  # 隐藏层大小
        self.num_layers = 2  # LSTM层数
        self.num_classes = 41  # 输出类别数
        self.seq_length = 30  # 序列长度
        self.num_workers = 8  # 数据加载线程数
        self.prefetch_factor = 2  # 预取因子
        self.pin_memory = True  # 固定内存
        self.mixed_precision = True  # 混合精度训练
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


# 特征提取类
class FeatureExtractor:
    """手部特征提取类，独立于数据集类"""

    def __init__(self, seq_length=30):
        self.seq_length = seq_length

    def extract_from_video(self, video_path):
        """从视频中提取手部关键点特征"""
        # 检查缓存
        cache_filename = os.path.join(
            Config().feature_cache_dir,
            f"{os.path.basename(video_path).split('.')[0]}.pkl"
        )

        # 如果缓存存在，直接加载
        if os.path.exists(cache_filename):
            with open(cache_filename, 'rb') as f:
                return pickle.load(f)

        # 否则提取特征
        cap = cv2.VideoCapture(video_path)
        frames = []

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            frames.append(frame)

        cap.release()

        # 确保frame数量一致
        total_frames = len(frames)
        if total_frames >= self.seq_length:
            # 均匀采样
            indices = np.linspace(0, total_frames - 1, self.seq_length, dtype=int)
            frames = [frames[i] for i in indices]
        else:
            # 补齐不足的帧
            frames = frames + [frames[-1]] * (self.seq_length - total_frames)

        # 初始化MediaPipe（在这里初始化而不是在构造函数中）
        mp_hands = mp.solutions.hands
        hands = mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5)

        # 使用MediaPipe提取手部关键点
        hand_features = []
        for frame in frames:
            # 转换BGR到RGB
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(rgb_frame)

            frame_features = []
            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks[:2]:  # 最多处理两只手
                    for landmark in hand_landmarks.landmark:
                        frame_features.extend([landmark.x, landmark.y])

            # 如果没有检测到手或只检测到一只手，用0填充
            if len(frame_features) < 84:
                frame_features.extend([0] * (84 - len(frame_features)))

            hand_features.append(frame_features[:84])  # 确保特征数量一致

        # 释放资源
        hands.close()

        # 缓存特征
        if not os.path.exists(Config().feature_cache_dir):
            os.makedirs(Config().feature_cache_dir)

        with open(cache_filename, 'wb') as f:
            pickle.dump(np.array(hand_features), f)

        return np.array(hand_features)


# 单进程处理视频特征提取函数（供并行处理使用）
def process_single_video(video_path):
    """处理单个视频并缓存特征"""
    extractor = FeatureExtractor()
    return extractor.extract_from_video(video_path)


# 预处理所有视频并缓存特征
def preprocess_all_videos(video_paths, n_jobs=-1):
    """并行预处理所有视频并缓存特征"""
    print("预处理并缓存所有视频特征...")
    if not os.path.exists(Config().feature_cache_dir):
        os.makedirs(Config().feature_cache_dir)

    # 检查已经处理过的视频
    processed_videos = []
    pending_videos = []

    for video_path in video_paths:
        cache_filename = os.path.join(
            Config().feature_cache_dir,
            f"{os.path.basename(video_path).split('.')[0]}.pkl"
        )
        if os.path.exists(cache_filename):
            processed_videos.append(video_path)
        else:
            pending_videos.append(video_path)

    print(f"已处理视频: {len(processed_videos)}/{len(video_paths)}")
    print(f"待处理视频: {len(pending_videos)}/{len(video_paths)}")

    if not pending_videos:
        print("所有视频已处理完毕！")
        return

    # 使用多进程处理未处理的视频
    if n_jobs != 1 and len(pending_videos) > 1:  # 并行处理
        try:
            # 尝试使用进程池
            from multiprocessing import Pool
            with Pool(processes=n_jobs) as pool:
                list(tqdm(pool.imap(process_single_video, pending_videos), total=len(pending_videos)))
        except Exception as e:
            print(f"并行处理出错: {e}，切换到顺序处理")
            for video_path in tqdm(pending_videos):
                process_single_video(video_path)
    else:  # 顺序处理
        for video_path in tqdm(pending_videos):
            process_single_video(video_path)

    print("预处理完成！")


# 优化的数据集类
class OptimizedHandSignDataset(Dataset):
    """优化的手语数据集类，使用缓存特征"""

    def __init__(self, video_paths, labels, transform=None):
        self.video_paths = video_paths
        self.labels = labels
        self.transform = transform

    def __len__(self):
        return len(self.video_paths)

    def __getitem__(self, idx):
        video_path = self.video_paths[idx]
        label = self.labels[idx]

        # 加载特征（从缓存中读取）
        cache_filename = os.path.join(
            Config().feature_cache_dir,
            f"{os.path.basename(video_path).split('.')[0]}.pkl"
        )

        with open(cache_filename, 'rb') as f:
            hand_features = pickle.load(f)

        # 转换为PyTorch张量
        hand_features = torch.FloatTensor(hand_features)
        label = torch.LongTensor([label])[0]

        # 应用变换
        if self.transform:
            # 数据增强
            if torch.rand(1).item() < 0.5:  # 50%概率应用增强
                # 添加少量噪声
                noise_level = 0.02
                noise = torch.randn_like(hand_features) * noise_level
                hand_features = hand_features + noise

        return hand_features, label


# 数据处理函数
def load_data(config):
    """加载视频和标签数据，在原有目录下重组织数据集"""
    # 读取语料库
    corpus_df = pd.read_csv(config.corpus_file, sep=' ', header=None, names=['index', 'text'])
    corpus_dict = dict(zip(corpus_df['index'].astype(str).str.zfill(6), corpus_df['text']))

    # 创建数据集划分目录（在原有目录下）
    dataset_splits = {
        'train': os.path.join(config.video_dir, 'train'),
        'val': os.path.join(config.video_dir, 'val'),
        'test': os.path.join(config.video_dir, 'test')
    }

    # 获取所有视频文件和标签（跳过已经划分的目录）
    video_paths = []
    labels = []
    for root, dirs, files in os.walk(config.video_dir):
        # 跳过train、val、test目录
        if any(split in root for split in ['train', 'val', 'test']):
            continue

        for file in files:
            if file.endswith('.avi'):
                video_path = os.path.join(root, file)
                # 从目录名提取标签索引
                dir_name = os.path.basename(os.path.dirname(video_path))
                try:
                    label_idx = int(dir_name)
                    video_paths.append(video_path)
                    labels.append(label_idx)
                except ValueError:
                    continue

    if not video_paths:  # 如果已经划分过，直接读取划分后的数据
        print("检测到数据集可能已经划分，正在读取划分后的数据...")
        splits_videos = {}
        splits_labels = {}

        for split_name, split_dir in dataset_splits.items():
            if os.path.exists(split_dir):
                videos = []
                labels = []
                for label_dir in os.listdir(split_dir):
                    label_path = os.path.join(split_dir, label_dir)
                    if os.path.isdir(label_path):
                        for video_name in os.listdir(label_path):
                            if video_name.endswith('.avi'):
                                videos.append(os.path.join(label_path, video_name))
                                labels.append(int(label_dir))
                splits_videos[split_name] = videos
                splits_labels[split_name] = labels

        if all(split in splits_videos for split in ['train', 'val', 'test']):
            print("成功读取已划分的数据集")
            all_videos = (splits_videos['train'] + splits_videos['val'] +
                          splits_videos['test'])
            preprocess_all_videos(all_videos, n_jobs=os.cpu_count())

            return (splits_videos['train'], splits_videos['val'], splits_videos['test'],
                    splits_labels['train'], splits_labels['val'], splits_labels['test'],
                    corpus_dict)

    print("开始划分数据集...")
    # 划分数据集
    train_videos, temp_videos, train_labels, temp_labels = train_test_split(
        video_paths, labels, test_size=0.3, random_state=42, stratify=labels
    )

    val_videos, test_videos, val_labels, test_labels = train_test_split(
        temp_videos, temp_labels, test_size=0.5, random_state=42, stratify=temp_labels
    )

    # 创建数据集目录
    for split_dir in dataset_splits.values():
        os.makedirs(split_dir, exist_ok=True)

    # 移动文件到对应目录
    splits_data = {
        'train': (train_videos, train_labels),
        'val': (val_videos, val_labels),
        'test': (test_videos, test_labels)
    }

    # 记录新的文件路径
    new_paths = {split: [] for split in splits_data.keys()}
    new_labels = {split: [] for split in splits_data.keys()}

    for split_name, (videos, split_labels) in splits_data.items():
        split_dir = dataset_splits[split_name]

        # 为每个类别创建子目录
        for label in set(split_labels):
            os.makedirs(os.path.join(split_dir, str(label)), exist_ok=True)

        # 移动文件
        for video_path, label in zip(videos, split_labels):
            # 创建目标路径
            dest_dir = os.path.join(split_dir, str(label))
            video_name = os.path.basename(video_path)
            dest_path = os.path.join(dest_dir, video_name)

            # 移动文件
            try:
                shutil.move(video_path, dest_path)
                new_paths[split_name].append(dest_path)
                new_labels[split_name].append(label)
            except Exception as e:
                print(f"移动文件时出错 {video_path}: {str(e)}")

    # 尝试删除空目录
    try:
        for root, dirs, files in os.walk(config.video_dir, topdown=False):
            for dir_name in dirs:
                dir_path = os.path.join(root, dir_name)
                if not os.listdir(dir_path) and not any(split in dir_path for split in ['train', 'val', 'test']):
                    os.rmdir(dir_path)
    except Exception as e:
        print(f"清理空目录时出错: {str(e)}")

    print("\n数据集划分完成！")
    print(f"训练集：{len(new_paths['train'])} 个视频")
    print(f"验证集：{len(new_paths['val'])} 个视频")
    print(f"测试集：{len(new_paths['test'])} 个视频")

    # 预处理所有视频
    all_videos = (new_paths['train'] + new_paths['val'] + new_paths['test'])
    preprocess_all_videos(all_videos, n_jobs=os.cpu_count())

    return (new_paths['train'], new_paths['val'], new_paths['test'],
            new_labels['train'], new_labels['val'], new_labels['test'],
            corpus_dict)


# 改进的模型定义
class ImprovedBiLSTMModel(nn.Module):
    """改进的双向LSTM模型，使用注意力机制"""

    def __init__(self, input_size, hidden_size, num_layers, num_classes):
        super(ImprovedBiLSTMModel, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers

        # 特征提取层
        self.feature_extractor = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.3)
        )

        # 双向LSTM
        self.lstm = nn.LSTM(
            hidden_size, hidden_size, num_layers,
            batch_first=True, bidirectional=True,
            dropout=0.3 if num_layers > 1 else 0
        )

        # 注意力机制
        self.attention = nn.Sequential(
            nn.Linear(hidden_size * 2, 1),
            nn.Tanh()
        )

        # 分类层
        self.classifier = nn.Sequential(
            nn.Linear(hidden_size * 2, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(hidden_size, num_classes)
        )

    def forward(self, x):
        batch_size, seq_len, input_dim = x.size()

        # 应用特征提取
        x = x.view(-1, input_dim)  # 展平所有序列
        x = self.feature_extractor(x)
        x = x.view(batch_size, seq_len, -1)  # 重塑回序列形式

        # 设置初始隐藏状态和单元状态
        h0 = torch.zeros(self.num_layers * 2, batch_size, self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers * 2, batch_size, self.hidden_size).to(x.device)

        # 前向传播LSTM
        outputs, _ = self.lstm(x, (h0, c0))  # outputs: [batch_size, seq_len, hidden_size*2]

        # 注意力机制
        attn_weights = self.attention(outputs)  # [batch_size, seq_len, 1]
        attn_weights = torch.softmax(attn_weights, dim=1)

        # 应用注意力权重
        context = torch.sum(outputs * attn_weights, dim=1)  # [batch_size, hidden_size*2]

        # 分类
        out = self.classifier(context)

        return out


# 优化的训练函数
def train_model(model, train_loader, val_loader, config, model_name="bilstm"):
    """训练模型，使用混合精度训练和TensorBoard记录"""
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model.parameters(), lr=config.learning_rate, weight_decay=1e-5)

    # 学习率调度器
    scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(
        optimizer, T_0=10, T_mult=1, eta_min=1e-6
    )

    # 早停
    early_stopping_counter = 0
    best_val_loss = float('inf')
    best_val_acc = 0.0

    # 混合精度训练
    scaler = torch.cuda.amp.GradScaler() if config.mixed_precision and torch.cuda.is_available() else None

    # TensorBoard记录器
    tb_logger = TensorboardLogger(f"logs/tensorboard/{model_name}")
    tb_logger.log_hyperparams(config)

    # 训练历史记录
    history = {
        'train_loss': [],
        'val_loss': [],
        'train_acc': [],
        'val_acc': []
    }

    for epoch in range(config.num_epochs):
        # 训练模式
        model.train()
        train_loss = 0
        train_correct = 0
        train_total = 0

        all_train_preds = []
        all_train_labels = []
        all_train_scores = []

        progress_bar = tqdm(train_loader, desc=f'Epoch {epoch + 1}/{config.num_epochs}')
        for batch_idx, (inputs, labels) in enumerate(progress_bar):
            inputs, labels = inputs.to(config.device), labels.to(config.device)

            # 清零梯度
            optimizer.zero_grad()

            if scaler is not None:
                # 混合精度训练
                with torch.cuda.amp.autocast():
                    outputs = model(inputs)
                    loss = criterion(outputs, labels)

                # 反向传播
                scaler.scale(loss).backward()

                # 梯度裁剪
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)

                # 优化器步进
                scaler.step(optimizer)
                scaler.update()
            else:
                # 常规训练
                outputs = model(inputs)
                loss = criterion(outputs, labels)

                # 反向传播和优化
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()

            # 更新学习率
            scheduler.step(epoch + batch_idx / len(train_loader))

            train_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            train_total += labels.size(0)
            train_correct += (predicted == labels).sum().item()

            # 收集预测和标签用于计算指标
            all_train_preds.extend(predicted.cpu().numpy())
            all_train_labels.extend(labels.cpu().numpy())
            all_train_scores.extend(torch.softmax(outputs, dim=1).detach().cpu().numpy())

            # 更新进度条
            progress_bar.set_postfix({
                'loss': f'{loss.item():.4f}',
                'acc': f'{100.0 * train_correct / train_total:.2f}%'
            })

        train_loss /= len(train_loader)
        train_acc = 100 * train_correct / train_total

        # 验证模式
        model.eval()
        val_loss = 0
        val_correct = 0
        val_total = 0

        all_val_preds = []
        all_val_labels = []
        all_val_scores = []

        with torch.no_grad():
            for inputs, labels in val_loader:
                inputs, labels = inputs.to(config.device), labels.to(config.device)

                if scaler is not None:
                    with torch.cuda.amp.autocast():
                        outputs = model(inputs)
                        loss = criterion(outputs, labels)
                else:
                    outputs = model(inputs)
                    loss = criterion(outputs, labels)

                val_loss += loss.item()
                _, predicted = torch.max(outputs.data, 1)
                val_total += labels.size(0)
                val_correct += (predicted == labels).sum().item()

                # 收集预测和标签用于计算指标
                all_val_preds.extend(predicted.cpu().numpy())
                all_val_labels.extend(labels.cpu().numpy())
                all_val_scores.extend(torch.softmax(outputs, dim=1).detach().cpu().numpy())

        val_loss /= len(val_loader)
        val_acc = 100 * val_correct / val_total

        # 打印训练信息
        print(
            f'Epoch {epoch + 1}: train_loss={train_loss:.4f}, train_acc={train_acc:.2f}%, val_loss={val_loss:.4f}, val_acc={val_acc:.2f}%')

        # 记录历史
        history['train_loss'].append(train_loss)
        history['val_loss'].append(val_loss)
        history['train_acc'].append(train_acc)
        history['val_acc'].append(val_acc)

        # 记录TensorBoard
        tb_logger.log_metrics(epoch, train_loss, val_loss, train_acc, val_acc)
        tb_logger.log_learning_rate(epoch, optimizer)
        
        # 记录sklearn指标
        tb_logger.log_sklearn_metrics(
            epoch, 
            np.array(all_val_labels), 
            np.array(all_val_preds),
            np.array(all_val_scores)
        )

        # 保存最佳模型
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            if not os.path.exists(config.model_save_path):
                os.makedirs(config.model_save_path)
            torch.save(model.state_dict(), os.path.join(config.model_save_path, f'best_{model_name}_model.pth'))
            early_stopping_counter = 0
            
            # 记录最佳验证指标
            precision, recall, f1, _ = precision_recall_fscore_support(
                all_val_labels, all_val_preds, average='weighted'
            )
            print(f"新的最佳模型！验证准确率: {val_acc:.2f}%, F1分数: {f1:.4f}")
            print(classification_report(all_val_labels, all_val_preds))
            
            # 绘制混淆矩阵
            cm = confusion_matrix(all_val_labels, all_val_preds)
            plt.figure(figsize=(10, 8))
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
            plt.xlabel('Predicted')
            plt.ylabel('True')
            plt.title(f'Confusion Matrix - {model_name}')
            plt.savefig(f'confusion_matrix_{model_name}.png')
            plt.close()
        else:
            early_stopping_counter += 1
            if early_stopping_counter >= config.patience:
                print(f'Early stopping at epoch {epoch + 1}')
                break

    # 关闭TensorBoard记录器
    tb_logger.close()

    return model, history


# 创建不同的模型
def create_model(model_type, config):
    """根据指定类型创建模型"""
    if model_type == "bilstm":
        return ImprovedBiLSTMModel(
            config.input_size,
            config.hidden_size,
            config.num_layers,
            config.num_classes
        ).to(config.device)
    elif model_type == "transformer":
        return TransformerModel(
            config.input_size,
            config.hidden_size,
            num_heads=8,
            num_layers=config.num_layers,
            num_classes=config.num_classes,
            dropout=0.3
        ).to(config.device)
    elif model_type == "cnn_lstm":
        return CNN_LSTM_Model(
            config.input_size,
            config.hidden_size,
            config.num_layers,
            config.num_classes,
            dropout=0.5
        ).to(config.device)
    elif model_type == "gru":
        return GRUModel(
            config.input_size,
            config.hidden_size,
            config.num_layers,
            config.num_classes,
            dropout=0.5
        ).to(config.device)
    else:
        raise ValueError(f"未知模型类型: {model_type}")


# 评估模型
def evaluate_model(model, test_loader, config, corpus_dict, model_name="model"):
    """评估模型并显示详细指标"""
    model.eval()
    test_correct = 0
    test_total = 0

    predictions = []
    true_labels = []
    all_scores = []

    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs, labels = inputs.to(config.device), labels.to(config.device)

            outputs = model(inputs)
            scores = torch.softmax(outputs, dim=1)
            _, predicted = torch.max(outputs.data, 1)

            test_total += labels.size(0)
            test_correct += (predicted == labels).sum().item()

            predictions.extend(predicted.cpu().numpy())
            true_labels.extend(labels.cpu().numpy())
            all_scores.extend(scores.cpu().numpy())

    # 计算指标
    test_acc = 100 * test_correct / test_total
    precision, recall, f1, _ = precision_recall_fscore_support(
        true_labels, predictions, average='weighted'
    )
    
    # 打印结果
    print(f"------- {model_name} 评估结果 -------")
    print(f'测试准确率: {test_acc:.2f}%')
    print(f'精确率: {precision:.4f}')
    print(f'召回率: {recall:.4f}')
    print(f'F1分数: {f1:.4f}')
    print("\n分类报告:")
    print(classification_report(true_labels, predictions))
    
    # 绘制混淆矩阵
    cm = confusion_matrix(true_labels, predictions)
    plt.figure(figsize=(12, 10))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title(f'Confusion Matrix - {model_name}')
    plt.savefig(f'test_confusion_matrix_{model_name}.png')
    
    # 输出一些例子
    print("\n示例预测结果:")
    for i in range(min(10, len(predictions))):
        pred_text = corpus_dict.get(str(predictions[i]).zfill(6), "未知")
        true_text = corpus_dict.get(str(true_labels[i]).zfill(6), "未知")
        confidence = np.max(all_scores[i])
        print(f"预测: {pred_text} ({confidence:.2%}) | 实际: {true_text}")
    
    return test_acc, precision, recall, f1


# 创建集成模型
def create_ensemble_model(config, model_paths):
    """创建并加载集成模型"""
    models = []
    
    # 加载每个模型
    for model_type, model_path in model_paths.items():
        model = create_model(model_type, config)
        model.load_state_dict(torch.load(model_path, map_location=config.device))
        model.eval()
        models.append(model)
    
    # 创建集成模型
    ensemble = EnsembleModel(models).to(config.device)
    
    return ensemble


# 主函数
def main():
    # 加载配置
    config = Config()

    # 加载数据
    train_videos, val_videos, test_videos, train_labels, val_labels, test_labels, corpus_dict = load_data(config)

    print(f"训练集大小: {len(train_videos)}")
    print(f"验证集大小: {len(val_videos)}")
    print(f"测试集大小: {len(test_videos)}")
    print(f"类别数量: {config.num_classes}")

    # 创建数据集
    train_dataset = OptimizedHandSignDataset(train_videos, train_labels, transform=True)
    val_dataset = OptimizedHandSignDataset(val_videos, val_labels)
    test_dataset = OptimizedHandSignDataset(test_videos, test_labels)

    # 处理数据不平衡
    class_counts = np.bincount(train_labels)
    weights = 1.0 / class_counts
    sample_weights = weights[train_labels]
    sampler = WeightedRandomSampler(
        weights=sample_weights,
        num_samples=len(sample_weights),
        replacement=True
    )

    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.batch_size,
        sampler=sampler,  # 使用加权采样器
        num_workers=config.num_workers,
        pin_memory=config.pin_memory,
        prefetch_factor=config.prefetch_factor
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=config.batch_size,
        num_workers=config.num_workers,
        pin_memory=config.pin_memory
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=config.batch_size,
        num_workers=config.num_workers,
        pin_memory=config.pin_memory
    )

    # 选择要训练的模型类型
    model_types = ["bilstm", "transformer", "cnn_lstm", "gru"]
    
    results = {}
    histories = {}
    
    for model_type in model_types:
        print(f"\n===== 训练 {model_type} 模型 =====")
        
        # 创建模型
        model = create_model(model_type, config)
        print(model)
        
        # 训练模型
        model, history = train_model(model, train_loader, val_loader, config, model_type)
        
        # 评估模型
        test_acc, precision, recall, f1 = evaluate_model(
            model, test_loader, config, corpus_dict, model_type
        )
        
        # 保存结果
        results[model_type] = {
            'accuracy': test_acc,
            'precision': precision,
            'recall': recall,
            'f1': f1
        }
        
        histories[model_type] = history
    
    # 比较不同模型
    print("\n===== 模型比较 =====")
    for model_type, metrics in results.items():
        print(f"{model_type}: 准确率={metrics['accuracy']:.2f}%, F1={metrics['f1']:.4f}")
    
    # 创建并评估集成模型
    print("\n===== 创建集成模型 =====")
    model_paths = {
        model_type: os.path.join(config.model_save_path, f'best_{model_type}_model.pth')
        for model_type in model_types
    }
    
    # 检查所有模型文件是否存在
    all_exists = True
    for path in model_paths.values():
        if not os.path.exists(path):
            all_exists = False
            print(f"模型文件不存在: {path}")
    
    if all_exists:
        ensemble_model = create_ensemble_model(config, model_paths)
        print("集成模型创建成功！评估集成模型...")
        
        # 评估集成模型
        evaluate_model(ensemble_model, test_loader, config, corpus_dict, "ensemble")
    
    # 绘制训练历史
    plt.figure(figsize=(15, 10))
    
    # 损失曲线
    plt.subplot(2, 2, 1)
    for model_type, history in histories.items():
        plt.plot(history['train_loss'], label=f'{model_type} Train')
    plt.title('Training Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    
    plt.subplot(2, 2, 2)
    for model_type, history in histories.items():
        plt.plot(history['val_loss'], label=f'{model_type} Val')
    plt.title('Validation Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    
    # 准确率曲线
    plt.subplot(2, 2, 3)
    for model_type, history in histories.items():
        plt.plot(history['train_acc'], label=f'{model_type} Train')
    plt.title('Training Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy (%)')
    plt.legend()
    
    plt.subplot(2, 2, 4)
    for model_type, history in histories.items():
        plt.plot(history['val_acc'], label=f'{model_type} Val')
    plt.title('Validation Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy (%)')
    plt.legend()
    
    plt.tight_layout()
    plt.savefig('model_comparison.png')
    plt.show()


if __name__ == "__main__":
    main()
