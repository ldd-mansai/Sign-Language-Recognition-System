
import torch
import torch.nn as nn


class CNN_LSTM_Model(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, num_classes, dropout=0.5):
        super(CNN_LSTM_Model, self).__init__()

        # CNN层用于提取空间特征
        self.cnn = nn.Sequential(
            nn.Conv1d(input_size, hidden_size, kernel_size=3, padding=1),
            nn.BatchNorm1d(hidden_size),
            nn.ReLU(),
            nn.Conv1d(hidden_size, hidden_size, kernel_size=3, padding=1),
            nn.BatchNorm1d(hidden_size),
            nn.ReLU(),
            nn.Dropout(dropout)
        )

        # LSTM层用于提取时序特征
        self.lstm = nn.LSTM(
            hidden_size, hidden_size, num_layers,
            batch_first=True, bidirectional=True,
            dropout=dropout if num_layers > 1 else 0
        )

        # 注意力机制
        self.attention = nn.Sequential(
            nn.Linear(hidden_size * 2, 1),
            nn.Tanh()
        )

        # 分类器
        self.classifier = nn.Sequential(
            nn.Linear(hidden_size * 2, hidden_size),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_size, num_classes)
        )

    def forward(self, x):
        # x的形状: [batch_size, seq_len, input_size]
        batch_size, seq_len, input_size = x.size()

        # 转换为CNN的输入形状 [batch_size, input_size, seq_len]
        x = x.transpose(1, 2)

        # 应用CNN
        x = self.cnn(x)

        # 转回LSTM的输入形状 [batch_size, seq_len, hidden_size]
        x = x.transpose(1, 2)

        # LSTM处理
        h0 = torch.zeros(2 * self.lstm.num_layers, batch_size, self.lstm.hidden_size).to(x.device)
        c0 = torch.zeros(2 * self.lstm.num_layers, batch_size, self.lstm.hidden_size).to(x.device)

        outputs, _ = self.lstm(x, (h0, c0))

        # 注意力机制
        attn_weights = self.attention(outputs)
        attn_weights = torch.softmax(attn_weights, dim=1)

        # 应用注意力权重
        context = torch.sum(outputs * attn_weights, dim=1)

        # 分类
        logits = self.classifier(context)

        return logits

    def get_attention_weights(self, x):
        """获取注意力权重用于可视化"""
        batch_size, seq_len, input_size = x.size()

        # 转换为CNN的输入形状
        x = x.transpose(1, 2)

        # 应用CNN
        x = self.cnn(x)

        # 转回LSTM的输入形状
        x = x.transpose(1, 2)

        # LSTM处理
        h0 = torch.zeros(2 * self.lstm.num_layers, batch_size, self.lstm.hidden_size).to(x.device)
        c0 = torch.zeros(2 * self.lstm.num_layers, batch_size, self.lstm.hidden_size).to(x.device)

        outputs, _ = self.lstm(x, (h0, c0))

        # 注意力权重
        attn_weights = self.attention(outputs)
        attn_weights = torch.softmax(attn_weights, dim=1)

        return attn_weights
