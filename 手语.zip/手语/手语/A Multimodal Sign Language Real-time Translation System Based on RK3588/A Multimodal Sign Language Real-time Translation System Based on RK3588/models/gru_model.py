

import torch
import torch.nn as nn


class GRUModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, num_classes, dropout=0.5):
        super(GRUModel, self).__init__()

        # 特征提取层
        self.feature_extractor = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(dropout)
        )

        # GRU层
        self.gru = nn.GRU(
            hidden_size, hidden_size, num_layers,
            batch_first=True, bidirectional=True,
            dropout=dropout if num_layers > 1 else 0
        )

        # 注意力机制
        self.attention = nn.Sequential(
            nn.Linear(hidden_size * 2, 1),
            nn.Tanh()
        )

        # 分类器
        self.classifier = nn.Sequential(
            nn.Linear(hidden_size * 2, hidden_size),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_size, num_classes)
        )

    def forward(self, x):
        # x的形状: [batch_size, seq_len, input_size]
        batch_size, seq_len, input_size = x.size()

        # 特征提取
        x = x.view(-1, input_size)
        x = self.feature_extractor(x)
        x = x.view(batch_size, seq_len, -1)

        # GRU处理
        h0 = torch.zeros(2 * self.gru.num_layers, batch_size, self.gru.hidden_size).to(x.device)

        outputs, _ = self.gru(x, h0)

        # 注意力机制
        attn_weights = self.attention(outputs)
        attn_weights = torch.softmax(attn_weights, dim=1)

        # 应用注意力权重
        context = torch.sum(outputs * attn_weights, dim=1)

        # 分类
        logits = self.classifier(context)

        return logits

    def get_attention_weights(self, x):
        """获取注意力权重用于可视化"""
        batch_size, seq_len, input_size = x.size()

        # 特征提取
        x = x.view(-1, input_size)
        x = self.feature_extractor(x)
        x = x.view(batch_size, seq_len, -1)

        # GRU处理
        h0 = torch.zeros(2 * self.gru.num_layers, batch_size, self.gru.hidden_size).to(x.device)

        outputs, _ = self.gru(x, h0)

        # 注意力机制
        attn_weights = self.attention(outputs)
        attn_weights = torch.softmax(attn_weights, dim=1)

        return attn_weights
