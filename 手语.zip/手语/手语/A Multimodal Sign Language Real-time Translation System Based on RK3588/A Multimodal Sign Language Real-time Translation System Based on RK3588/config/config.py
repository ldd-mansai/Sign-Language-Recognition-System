

import os

import torch


class Config:
    """配置参数"""

    def __init__(self):
        # 基础配置
        self.video_dir = 'dataset'
        self.corpus_file = 'dataset/corpus.txt'
        self.model_save_path = 'models/'
        self.feature_cache_dir = 'features/'

        # 模型参数
        self.input_size = 42 * 2
        self.hidden_size = 256
        self.num_layers = 3
        self.num_classes = 41
        self.num_heads = 8

        # 训练参数
        self.batch_size = 32
        self.learning_rate = 3e-4
        self.num_epochs = 100
        self.patience = 15
        self.seq_length = 30
        self.weight_decay = 1e-4
        self.gradient_clip = 1.0
        self.warmup_epochs = 5
        self.label_smoothing = 0.1

        # 数据增强参数
        self.noise_prob = 0.5
        self.noise_level = 0.05
        self.time_warp_prob = 0.3
        self.spatial_transform_prob = 0.3
        self.mask_prob = 0.2

        # 训练优化参数
        self.num_workers = 8
        self.prefetch_factor = 2
        self.pin_memory = True
        self.mixed_precision = True
        self.ema_decay = 0.995

        # 设备配置
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        # 创建必要的目录
        for path in [self.model_save_path, self.feature_cache_dir]:
            os.makedirs(path, exist_ok=True)
