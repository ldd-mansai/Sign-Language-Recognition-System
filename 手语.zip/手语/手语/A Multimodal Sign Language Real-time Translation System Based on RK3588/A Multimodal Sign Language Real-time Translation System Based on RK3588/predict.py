

import argparse
import os
import pickle
import warnings

import cv2
import mediapipe as mp
import numpy as np
import pandas as pd
import torch
import torch.nn as nn

from models.cnn_lstm_model import CNN_LSTM_Model
from models.gru_model import GRUModel
from models.transformer_model import TransformerModel

warnings.filterwarnings('ignore')


class Config:
    """配置参数"""

    def __init__(self):
        self.feature_cache_dir = 'features/'  # 特征缓存目录
        self.model_save_path = 'models/'  # 模型保存目录
        self.corpus_file = 'dataset/corpus.txt'  # 语料库文件
        self.input_size = 42 * 2  # 输入特征维度
        self.hidden_size = 128  # 隐藏层大小
        self.num_layers = 2  # LSTM层数
        self.num_classes = 41  # 输出类别数
        self.seq_length = 30  # 序列长度
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


class FeatureExtractor:
    """手部特征提取类"""

    def __init__(self, seq_length=30):
        self.seq_length = seq_length

    def extract_from_video(self, video_path, use_cache=True):
        """从视频中提取手部关键点特征"""
        # 检查缓存
        if use_cache:
            cache_filename = os.path.join(
                Config().feature_cache_dir,
                f"{os.path.basename(video_path).split('.')[0]}.pkl"
            )
            if os.path.exists(cache_filename):
                with open(cache_filename, 'rb') as f:
                    return pickle.load(f)

        # 读取视频帧
        cap = cv2.VideoCapture(video_path)
        frames = []
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            frames.append(frame)
        cap.release()

        # 确保frame数量一致
        total_frames = len(frames)
        if total_frames >= self.seq_length:
            indices = np.linspace(0, total_frames - 1, self.seq_length, dtype=int)
            frames = [frames[i] for i in indices]
        else:
            frames = frames + [frames[-1]] * (self.seq_length - total_frames)

        # 初始化MediaPipe
        mp_hands = mp.solutions.hands
        hands = mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )

        # 提取手部关键点
        hand_features = []
        for frame in frames:
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(rgb_frame)

            frame_features = []
            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks[:2]:
                    for landmark in hand_landmarks.landmark:
                        frame_features.extend([landmark.x, landmark.y])

            if len(frame_features) < 84:
                frame_features.extend([0] * (84 - len(frame_features)))

            hand_features.append(frame_features[:84])

        hands.close()

        # 缓存特征
        if use_cache:
            if not os.path.exists(Config().feature_cache_dir):
                os.makedirs(Config().feature_cache_dir)
            with open(cache_filename, 'wb') as f:
                pickle.dump(np.array(hand_features), f)

        return np.array(hand_features)

    def extract_from_frames(self, frames):
        """从帧序列中提取手部关键点特征"""
        # 确保frame数量一致
        total_frames = len(frames)
        if total_frames >= self.seq_length:
            indices = np.linspace(0, total_frames - 1, self.seq_length, dtype=int)
            frames = [frames[i] for i in indices]
        else:
            frames = frames + [frames[-1]] * (self.seq_length - total_frames)

        # 初始化MediaPipe
        mp_hands = mp.solutions.hands
        hands = mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )

        # 提取手部关键点
        hand_features = []
        for frame in frames:
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(rgb_frame)

            frame_features = []
            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks[:2]:
                    for landmark in hand_landmarks.landmark:
                        frame_features.extend([landmark.x, landmark.y])

            if len(frame_features) < 84:
                frame_features.extend([0] * (84 - len(frame_features)))

            hand_features.append(frame_features[:84])

        hands.close()
        return np.array(hand_features)

    def extract_from_webcam(self, duration=3):
        """从摄像头实时提取手部关键点特征"""
        # 打开摄像头
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("无法打开摄像头")
            return None

        frames = []
        start_time = cv2.getTickCount()
        duration_sec = duration
        fps = cap.get(cv2.CAP_PROP_FPS)
        if fps <= 0:
            fps = 30  # 默认帧率

        # 计算需要捕获的帧数
        total_frames = int(fps * duration_sec)

        # 初始化MediaPipe用于实时显示
        mp_hands = mp.solutions.hands
        mp_drawing = mp.solutions.drawing_utils
        hands = mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )

        print(f"请在{duration_sec}秒内做出手语动作...")

        # 捕获视频帧
        while len(frames) < total_frames:
            ret, frame = cap.read()
            if not ret:
                break

            # 处理帧
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(rgb_frame)

            # 在帧上绘制手部关键点
            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    mp_drawing.draw_landmarks(
                        frame,
                        hand_landmarks,
                        mp_hands.HAND_CONNECTIONS
                    )

            # 显示倒计时
            elapsed_time = (cv2.getTickCount() - start_time) / cv2.getTickFrequency()
            remaining_time = max(0, duration_sec - elapsed_time)
            cv2.putText(
                frame,
                f"Remaining: {remaining_time:.1f}s",
                (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 255, 0),
                2
            )

            # 显示帧
            cv2.imshow('Hand Sign Input', frame)

            # 保存帧
            frames.append(frame.copy())

            # 按ESC键退出
            if cv2.waitKey(1) == 27:
                break

        # 释放资源
        cap.release()
        cv2.destroyAllWindows()
        hands.close()

        # 提取特征
        return self.extract_from_frames(frames)


class ImprovedBiLSTMModel(nn.Module):
    """改进的双向LSTM模型"""

    def __init__(self, input_size, hidden_size, num_layers, num_classes):
        super(ImprovedBiLSTMModel, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers

        self.feature_extractor = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.3)
        )

        self.lstm = nn.LSTM(
            hidden_size, hidden_size, num_layers,
            batch_first=True, bidirectional=True,
            dropout=0.3 if num_layers > 1 else 0
        )

        self.attention = nn.Sequential(
            nn.Linear(hidden_size * 2, 1),
            nn.Tanh()
        )

        self.classifier = nn.Sequential(
            nn.Linear(hidden_size * 2, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(hidden_size, num_classes)
        )

    def forward(self, x):
        batch_size, seq_len, input_dim = x.size()

        x = x.view(-1, input_dim)
        x = self.feature_extractor(x)
        x = x.view(batch_size, seq_len, -1)

        h0 = torch.zeros(self.num_layers * 2, batch_size, self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers * 2, batch_size, self.hidden_size).to(x.device)

        outputs, _ = self.lstm(x, (h0, c0))

        attn_weights = self.attention(outputs)
        attn_weights = torch.softmax(attn_weights, dim=1)

        context = torch.sum(outputs * attn_weights, dim=1)

        out = self.classifier(context)

        return out


class HandSignPredictor:
    """手语预测器类"""

    def __init__(self, model_type="bilstm", model_path=None):
        self.config = Config()

        # 加载语料库
        corpus_df = pd.read_csv(
            self.config.corpus_file,
            sep=' ',
            header=None,
            names=['index', 'text']
        )
        self.corpus_dict = dict(zip(
            corpus_df['index'].astype(str).str.zfill(6),
            corpus_df['text']
        ))

        # 初始化模型
        self.model_type = model_type
        self.model = self._create_model(model_type)

        # 加载模型权重
        if model_path is None:
            model_path = os.path.join(self.config.model_save_path, f'best_{model_type}_model.pth')

        if os.path.exists(model_path):
            self.model.load_state_dict(torch.load(
                model_path,
                map_location=self.config.device
            ))
            print(f"模型已加载: {model_path}")
        else:
            raise FileNotFoundError(f"模型文件未找到: {model_path}")

        self.feature_extractor = FeatureExtractor(self.config.seq_length)
        self.model.eval()

    def _create_model(self, model_type):
        """创建指定类型的模型"""
        if model_type == "bilstm":
            return ImprovedBiLSTMModel(
                self.config.input_size,
                self.config.hidden_size,
                self.config.num_layers,
                self.config.num_classes
            ).to(self.config.device)
        elif model_type == "transformer":
            return TransformerModel(
                self.config.input_size,
                self.config.hidden_size,
                num_heads=8,
                num_layers=self.config.num_layers,
                num_classes=self.config.num_classes,
                dropout=0.3
            ).to(self.config.device)
        elif model_type == "cnn_lstm":
            return CNN_LSTM_Model(
                self.config.input_size,
                self.config.hidden_size,
                self.config.num_layers,
                self.config.num_classes,
                dropout=0.5
            ).to(self.config.device)
        elif model_type == "gru":
            return GRUModel(
                self.config.input_size,
                self.config.hidden_size,
                self.config.num_layers,
                self.config.num_classes,
                dropout=0.5
            ).to(self.config.device)
        else:
            raise ValueError(f"未知模型类型: {model_type}")

    def predict(self, video_path, return_prob=False):
        """
        预测视频中的手语内容
        
        参数:
            video_path (str): 视频文件路径
            return_prob (bool): 是否返回预测概率
            
        返回:
            如果 return_prob=False:
                str: 预测的文本
            如果 return_prob=True:
                tuple: (预测的文本, 预测的概率)
        """
        # 提取特征
        features = self.feature_extractor.extract_from_video(video_path)
        features = torch.FloatTensor(features).unsqueeze(0).to(self.config.device)

        # 预测
        with torch.no_grad():
            outputs = self.model(features)
            probabilities = torch.softmax(outputs, dim=1)
            confidence, predicted = torch.max(probabilities, 1)

            predicted_idx = predicted.item()
            confidence = confidence.item()
            predicted_text = self.corpus_dict.get(
                str(predicted_idx).zfill(6),
                "未知"
            )

        if return_prob:
            return predicted_text, confidence
        return predicted_text

    def predict_webcam(self, duration=3, return_prob=False):
        """
        从摄像头预测手语内容
        
        参数:
            duration (int): 录制时长，单位为秒
            return_prob (bool): 是否返回预测概率
            
        返回:
            如果 return_prob=False:
                str: 预测的文本
            如果 return_prob=True:
                tuple: (预测的文本, 预测的概率)
        """
        features = self.feature_extractor.extract_from_webcam(duration)
        if features is None:
            if return_prob:
                return "无法获取摄像头输入", 0.0
            return "无法获取摄像头输入"

        features = torch.FloatTensor(features).unsqueeze(0).to(self.config.device)

        # 预测
        with torch.no_grad():
            outputs = self.model(features)
            probabilities = torch.softmax(outputs, dim=1)
            confidence, predicted = torch.max(probabilities, 1)

            predicted_idx = predicted.item()
            confidence = confidence.item()
            predicted_text = self.corpus_dict.get(
                str(predicted_idx).zfill(6),
                "未知"
            )

        if return_prob:
            return predicted_text, confidence
        return predicted_text


def main():
    """主函数 - 命令行界面"""
    parser = argparse.ArgumentParser(description='手语识别预测器')
    parser.add_argument('--model', type=str, default='cnn_lstm',
                        choices=['bilstm', 'transformer', 'cnn_lstm', 'gru'],
                        help='模型类型')
    parser.add_argument('--video', type=str, default=None,
                        help='视频文件路径')
    parser.add_argument('--webcam', action='store_true',
                        help='使用摄像头进行实时预测')
    parser.add_argument('--duration', type=int, default=3,
                        help='摄像头录制时长（秒）')

    args = parser.parse_args()

    try:
        predictor = HandSignPredictor(model_type=args.model)

        if args.video:
            # 预测视频文件
            predicted_text, confidence = predictor.predict(args.video, return_prob=True)
            print(f"视频: {args.video}")
            print(f"预测结果: {predicted_text}")
            print(f"置信度: {confidence:.2%}")
        elif args.webcam:
            # 使用摄像头
            predicted_text, confidence = predictor.predict_webcam(
                duration=args.duration,
                return_prob=True
            )
            print(f"预测结果: {predicted_text}")
            print(f"置信度: {confidence:.2%}")
        else:
            # 交互式模式
            print("=== 手语识别交互模式 ===")
            print("1. 输入视频文件路径")
            print("2. 使用摄像头录制")
            print("q. 退出")

            while True:
                choice = input("\n请选择 [1/2/q]: ")

                if choice == 'q':
                    break
                elif choice == '1':
                    video_path = input("请输入视频文件路径: ")
                    if os.path.exists(video_path):
                        predicted_text, confidence = predictor.predict(video_path, return_prob=True)
                        print(f"预测结果: {predicted_text}")
                        print(f"置信度: {confidence:.2%}")
                    else:
                        print(f"文件不存在: {video_path}")
                elif choice == '2':
                    duration = int(input("请输入录制时长（秒）: "))
                    predicted_text, confidence = predictor.predict_webcam(
                        duration=duration,
                        return_prob=True
                    )
                    print(f"预测结果: {predicted_text}")
                    print(f"置信度: {confidence:.2%}")
                else:
                    print("无效选择，请重试")
    except Exception as e:
        print(f"预测出错: {str(e)}")


if __name__ == "__main__":
    main()
