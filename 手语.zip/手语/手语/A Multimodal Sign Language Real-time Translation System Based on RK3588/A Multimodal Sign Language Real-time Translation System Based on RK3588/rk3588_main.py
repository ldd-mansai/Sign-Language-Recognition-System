import os
import threading
import time
import queue
import cv2
import numpy as np
import tkinter as tk
from tkinter import ttk, filedialog, Scale
from PIL import Image, ImageTk
import mediapipe as mp
import platform
import subprocess
import logging

# 首先配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('SignLanguageApp')

# 设置Linux显示环境变量
if platform.system() == "Linux":
    # 尝试多个可能的显示环境变量
    displays = [':0', ':1', ':0.0', ':1.0']
    for display in displays:
        try:
            os.environ['DISPLAY'] = display
            # 测试显示是否可用
            test_root = tk.Tk()
            test_root.destroy()
            logger.info(f"成功设置显示环境: DISPLAY={display}")
            break
        except Exception as e:
            logger.warning(f"无法设置显示环境 {display}: {str(e)}")
    else:
        # 如果所有尝试都失败，设置默认值
        os.environ['DISPLAY'] = ':0'
        logger.warning(f"无法确定显示环境，使用默认DISPLAY={os.environ['DISPLAY']}")

# RK3588摄像头设备路径
CAMERA_DEVICES = [
    '/dev/video11',  # RK3588 MIPI主摄像头
    '/dev/video0',   # USB摄像头备份路径
    '/dev/video13',  # 可能的辅助摄像头
    '/dev/video2',   # 可能的后备路径
]

# 路径配置
MODEL_PATH = "new.rknn"
CORPUS_PATH = "corpus.txt"

# UI配色方案
PRIMARY_COLOR = "#3498db"    # 主色 - 蓝色
SECONDARY_COLOR = "#2ecc71"  # 辅色 - 绿色
ACCENT_COLOR = "#e74c3c"     # 强调色 - 红色
BACKGROUND_COLOR = "#2c3e50"  # 背景色 - 深蓝
TEXT_COLOR = "#ecf0f1"       # 文字色 - 白色

def softmax(x, axis=None):
    """NumPy 实现的 softmax 函数"""
    e_x = np.exp(x - np.max(x, axis=axis, keepdims=True))
    return e_x / e_x.sum(axis=axis, keepdims=True)

# RKNN库导入处理
try:
    from rknnlite.api import RKNNLite as RKNN
    RKNN_AVAILABLE = True
    logger.info("导入 rknnlite.api.RKNNLite 成功")
except ImportError:
    try:
        from rknn.api import RKNN
        RKNN_AVAILABLE = True
        logger.info("导入 rknn.api.RKNN 成功")
    except ImportError:
        RKNN_AVAILABLE = False
        logger.warning("RKNN库未找到，使用模拟模式")
        
        class RKNN:
            def load_rknn(self, model_path):
                logger.info(f"模拟加载模型: {model_path}")
                return 0
            def init_runtime(self, *args, **kwargs):
                logger.info("模拟初始化运行时")
                return 0
            def inference(self, *args, **kwargs):
                logger.info("模拟推理")
                # 返回随机结果
                return [[np.random.rand(41)]]
            def release(self):
                logger.info("模拟释放资源")
            def get_input_details(self):
                return [{
                    'shape': (1, 1, 2520),
                    'dtype': np.float32,
                    'layout': 'nchw'
                }]

class Config:
    """配置参数"""
    def __init__(self):
        self.corpus_file = CORPUS_PATH
        self.rknn_model_path = MODEL_PATH
        self.ui_font = ('Microsoft YaHei UI', 10)
        self.title_font = ('Microsoft YaHei UI', 12, 'bold')  # 减小字体大小
        self.result_font = ('Microsoft YaHei UI', 16, 'bold')  # 减小字体大小
        self.camera_width = 480   # 减小预览宽度
        self.camera_height = 270  # 减小预览高度
        self.button_width = 140    # 减小按钮宽度
        self.button_height = 35    # 减小按钮高度

class FeatureExtractor:
    """手部特征提取类"""

    def __init__(self, seq_length=30):
        self.seq_length = seq_length
        logger.info(f"特征提取器初始化，序列长度={seq_length}")
        
        # 初始化MediaPipe绘图工具
        self.mp_hands = mp.solutions.hands
        self.mp_drawing = mp.solutions.drawing_utils
        self.mp_drawing_styles = mp.solutions.drawing_styles
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )

    def extract_from_video(self, video_path):
        """从视频中提取手部关键点特征并返回带关键点的帧"""
        logger.info(f"开始从视频提取特征: {video_path}")
        # 读取视频帧
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            logger.error(f"无法打开视频文件: {video_path}")
            return None, None
            
        frames = []
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            frames.append(frame)
        cap.release()

        # 确保frame数量一致
        if not frames:
            logger.error(f"视频中没有帧: {video_path}")
            return None, None
            
        # 处理帧并提取特征
        return self._process_frames(frames)

    def extract_from_frames(self, frames):
        """从帧序列中提取手部关键点特征并返回带关键点的帧"""
        if not frames:
            logger.error("提取特征失败: 没有帧输入")
            return None, None
            
        return self._process_frames(frames)

    def extract_from_webcam(self, cap, duration=3):
        """从摄像头实时提取手部关键点特征"""
        logger.info(f"开始从摄像头提取特征，持续时间={duration}秒")
        if not cap or not cap.isOpened():
            logger.error("摄像头未打开，无法提取特征")
            return None, None

        frames = []
        start_time = time.time()
        duration_sec = duration

        # 计算需要捕获的帧数
        fps = cap.get(cv2.CAP_PROP_FPS)
        if fps <= 0:
            fps = 15  # 默认帧率
            
        total_frames = int(fps * duration_sec)
        logger.info(f"目标帧数: {total_frames} (FPS={fps})")
        
        frame_count = 0
        
        # 捕获视频帧
        while frame_count < total_frames:
            ret, frame = cap.read()
            if not ret:
                logger.warning("摄像头读取失败")
                break

            # 保存帧
            frames.append(frame.copy())
            frame_count += 1
            
            # 计算剩余时间
            elapsed_time = time.time() - start_time
            if elapsed_time >= duration_sec:
                break

        logger.info(f"成功捕获 {len(frames)} 帧视频")

        # 提取特征
        return self._process_frames(frames)

    def _process_frames(self, frames):
        """处理帧序列并提取特征，返回特征和带关键点的帧"""
        logger.info(f"开始处理帧序列，帧数={len(frames)}")
        # 确保frame数量一致
        total_frames = len(frames)
        if total_frames == 0:
            logger.error("处理特征失败: 没有帧")
            return None, None
            
        if total_frames >= self.seq_length:
            indices = np.linspace(0, total_frames - 1, self.seq_length, dtype=int)
            frames = [frames[i] for i in indices]
            logger.info(f"视频有{total_frames}帧，采样{self.seq_length}帧")
        else:
            # 使用最后帧填充
            last_frame = frames[-1] if frames else None
            while len(frames) < self.seq_length:
                frames.append(last_frame)
            logger.info(f"视频只有{total_frames}帧，填充至{self.seq_length}帧")

        # 提取手部关键点
        hand_features = []
        annotated_frames = []  # 存储带关键点的帧
        
        for idx, frame in enumerate(frames):
            # 跳过空帧
            if frame is None:
                logger.warning(f"跳过空帧 #{idx}")
                hand_features.append([0]*84)
                annotated_frames.append(np.zeros((100, 100, 3), dtype=np.uint8))
                continue
                
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = self.hands.process(rgb_frame)

            frame_features = []
            annotated_frame = frame.copy()
            
            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    # 绘制关键点
                    self.mp_drawing.draw_landmarks(
                        annotated_frame,
                        hand_landmarks,
                        self.mp_hands.HAND_CONNECTIONS,
                        self.mp_drawing_styles.get_default_hand_landmarks_style(),
                        self.mp_drawing_styles.get_default_hand_connections_style())
                    
                    # 提取坐标
                    for landmark in hand_landmarks.landmark:
                        frame_features.extend([landmark.x, landmark.y])

            # 确保特征长度一致 (84个值: 21个关键点 * 2个坐标 * 2只手)
            if len(frame_features) < 84:
                # 用0填充
                padding = [0.0] * (84 - len(frame_features))
                frame_features.extend(padding)
                if len(frame_features) < 84:
                    logger.warning(f"特征长度不足: {len(frame_features)} < 84")

            hand_features.append(frame_features[:84])
            annotated_frames.append(annotated_frame)
        
        # 转换为NumPy数组
        features = np.array(hand_features, dtype=np.float32)
        logger.info(f"成功提取特征，形状={features.shape}")
        return features, annotated_frames


class SignLanguageRecognizer:
    """手语识别器（RK3588版）使用rknnlite"""

    def __init__(self, rknn_path):
        """初始化识别器"""
        logger.info("初始化手语识别器...")
        # 初始化RKNN运行时
        self.rknn = RKNN()
        self._load_model(rknn_path)
        
        # 加载语料库
        self.corpus_dict = self._load_corpus(CORPUS_PATH)
        
        # 预热模型
        self._warm_up()

    def _load_corpus(self, corpus_file):
        """加载语料库"""
        corpus_dict = {}
        try:
            logger.info(f"正在加载语料库: {corpus_file}")
            with open(corpus_file, 'r', encoding='utf-8') as f:
                for line in f:
                    parts = line.strip().split(maxsplit=1)
                    if len(parts) == 2:
                        index = parts[0].zfill(6)
                        corpus_dict[index] = parts[1]
            logger.info(f"语料库加载成功: 共{len(corpus_dict)}条记录")
        except Exception as e:
            logger.error(f"加载语料库失败: {str(e)}")
            corpus_dict = {str(i).zfill(6): f"手势{i}" for i in range(41)}
            logger.warning(f"使用模拟语料库: {len(corpus_dict)}条记录")
        return corpus_dict

    def _load_model(self, rknn_path):
        """加载RKNN模型"""
        if not os.path.exists(rknn_path):
            error_msg = f"找不到RKNN模型: {rknn_path}"
            logger.error(error_msg)
            raise FileNotFoundError(error_msg)

        logger.info(f"正在加载RKNN模型: {rknn_path}")
        
        # 加载模型
        ret = self.rknn.load_rknn(rknn_path)
        if ret != 0:
            error_msg = f"加载RKNN模型失败, 错误码: {ret}"
            logger.error(error_msg)
            raise RuntimeError(error_msg)

        # 初始化运行时
        try:
            logger.info('初始化运行时环境')
            # 尝试多种初始化方式
            try:
                ret = self.rknn.init_runtime()
                if ret != 0:
                    error_msg = f"标准初始化失败, 错误码: {ret}"
                    raise RuntimeError(error_msg)
            except Exception as e1:
                logger.warning(f"标准初始化失败: {str(e1)}, 尝试备选方式...")
                try:
                    # 尝试指定核心
                    ret = self.rknn.init_runtime(core_mask=RKNN.NPU_CORE_0)
                    if ret != 0:
                        error_msg = f"指定核心初始化失败, 错误码: {ret}"
                        raise RuntimeError(error_msg)
                except Exception as e2:
                    logger.warning(f"指定核心初始化失败: {str(e2)}, 尝试最后方式...")
                    # 尝试无参数初始化
                    ret = self.rknn.init_runtime()
                    if ret != 0:
                        error_msg = f"无参数初始化失败, 错误码: {ret}"
                        raise RuntimeError(error_msg)
            
            logger.info('RKNN模型加载成功')
        except Exception as e:
            error_msg = f"初始化运行时出错: {str(e)}"
            logger.error(error_msg)
            raise RuntimeError(f"无法初始化RKNN运行时: {str(e)}")

    def _warm_up(self):
        """预热模型"""
        logger.info("预热模型...")
        for i in range(3):
            logger.info(f"预热迭代 #{i+1}")
            # 随机输入
            fake_features = np.random.rand(1, 30, 84).astype(np.float32)
            try:
                predicted_text, confidence = self.predict(fake_features)
                logger.info(f"预热预测结果: {predicted_text} ({confidence:.2f})")
            except Exception as e:
                logger.warning(f"预热预测失败: {str(e)}")
            time.sleep(0.1)
        logger.info("模型预热完成")

    def predict(self, features):
        """执行预测"""
        if features is None or features.size == 0:
            logger.warning("预测请求但无特征输入")
            return "无输入", 0.0
            
        try:
            logger.debug(f"输入特征形状: {features.shape}, 类型: {features.dtype}")
            
            # 确保数据类型正确
            if features.dtype != np.float32:
                features = features.astype(np.float32)
                logger.debug(f"转换特征数据类型为float32")
                
            # 如果特征维度不足，添加批次维度
            if features.ndim == 2:
                # 假设形状为(seq, features) -> (1, seq, features)
                input_data = np.expand_dims(features, axis=0)
                logger.debug(f"添加批次维度，新形状: {input_data.shape}")
            elif features.ndim == 3:
                # 形状为(batch, seq, features) - 符合要求
                input_data = features
            else:
                # 无效形状
                logger.error(f"无效特征维度: {features.ndim}，期望2或3")
                return "输入错误", 0.0
                
            # 推理
            start = time.time()
            outputs = self.rknn.inference(inputs=[input_data])
            inference_time = time.time() - start
            
            logger.debug(f"推理时间: {inference_time*1000:.2f}ms")

            # 处理输出
            if outputs and len(outputs) > 0 and outputs[0].size > 0:
                # 获取第一个输出并应用softmax
                logits = outputs[0][0]
                softmax_probs = softmax(logits)
                
                # 获取预测结果
                class_id = np.argmax(softmax_probs)
                confidence = np.max(softmax_probs)
                
                # 查找语料库
                predicted_text = self.corpus_dict.get(str(class_id).zfill(6), "未知")
                
                logger.info(f"预测结果: {predicted_text}, 置信度: {confidence:.4f}")
                return predicted_text, confidence

            logger.error("RKNN推理返回空结果")
            return "推理错误", 0.0
        except Exception as e:
            logger.error(f"预测过程中出错: {str(e)}", exc_info=True)
            return "识别失败", 0.0

    def release(self):
        """释放资源"""
        if hasattr(self, 'rknn'):
            logger.info("正在释放RKNN资源...")
            self.rknn.release()
            logger.info("RKNN资源已释放")
        else:
            logger.warning("没有RKNN资源可释放")


class SignLanguageApp:
    def __init__(self, root):
        logger.info("===== 初始化手语识别系统 =====")
        self.root = root
        self.root.title("手语识别系统 - RK3588")
        
        # 固定窗口大小
        self.root.geometry("800x600")
        self.root.minsize(800, 600)
        self.root.maxsize(800, 600)
        self.root.config(bg=BACKGROUND_COLOR)
        
        # 尺寸配置
        self.config = Config()
        self.preview_width = self.config.camera_width
        self.preview_height = self.config.camera_height
        logger.info(f"预览尺寸: {self.preview_width}x{self.preview_height}")
        
        # 初始化属性
        self.is_camera_running = False
        self.is_recording = False
        self.cap = None
        self.feature_extractor = FeatureExtractor()
        self.recognizer = None
        self.video_path = None
        self.recording_frames = []
        self.recording_thread = None
        self.processing_thread = None
        self.last_prediction_time = 0
        self.current_prediction = ("", 0.0)
        self.processing_file = False
        self.last_frame_time = time.time()
        self.frame_count = 0
        self.fps = 0
        self.capture_duration = 10  # 默认录制时间10秒

        # 创建UI组件
        self.create_widgets()
        
        # 尝试获取摄像头权限
        self.fix_linux_permissions()
        
        # 加载模型
        self.load_model()

    def fix_linux_permissions(self):
        """在Linux上修复摄像头权限问题"""
        if platform.system() != "Linux":
            return
            
        logger.info("检查摄像头设备权限...")
        for device in CAMERA_DEVICES:
            if os.path.exists(device) and not os.access(device, os.R_OK | os.W_OK):
                try:
                    logger.info(f"尝试修复 {device} 权限")
                    subprocess.run(['sudo', 'chmod', 'a+rw', device])
                    logger.info(f"{device} 权限修复成功")
                except Exception as e:
                    logger.error(f"权限修复失败: {str(e)}")

    def load_model(self):
        """加载模型"""
        try:
            logger.info("正在加载RKNN预测模型...")
            self.recognizer = SignLanguageRecognizer(MODEL_PATH)
            self.update_info("模型加载成功")
        except Exception as e:
            error_msg = f"模型加载失败: {str(e)}"
            self.update_info(error_msg)
            self.result_label.config(text="模型加载失败")
            logger.error(error_msg)

    def update_info(self, message):
        """更新状态信息"""
        self.status_label.config(text=message[:60])
        logger.info(f"状态更新: {message}")
        
    def update_progress(self, value, message=None):
        """更新进度条"""
        self.progress_var.set(value)
        if message:
            self.progress_label.config(text=message)

    def update_duration(self, value):
        """更新录制时长"""
        self.capture_duration = int(value)
        self.update_info(f"识别时长已设置为 {value} 秒")

    def select_video_file(self):
        """选择视频文件"""
        logger.info("选择视频文件...")
        file_path = filedialog.askopenfilename(
            title="选择视频文件",
            filetypes=[("视频文件", "*.mp4 *.avi *.mov *.mkv"), ("所有文件", "*.*")]
        )
        
        if file_path:
            self.video_path = file_path
            self.update_info(f"已选择视频: {os.path.basename(file_path)}")
            self.process_button.config(state=tk.NORMAL, bg=SECONDARY_COLOR)
            logger.info(f"已选择视频文件: {file_path}")

    def process_video_file(self):
        """处理视频文件"""
        logger.info("开始处理视频文件...")
        if not self.video_path or not os.path.exists(self.video_path):
            self.update_info("请先选择有效的视频文件")
            logger.warning("视频文件无效或未选择")
            return
            
        if self.is_camera_running:
            self.update_info("请先停止摄像头")
            logger.warning("摄像头正在运行，无法处理视频文件")
            return
            
        self.processing_file = True
        self.file_button.config(state=tk.DISABLED)
        self.process_button.config(state=tk.DISABLED)
        self.result_label.config(text="处理中...")
        self.confidence_label.config(text="0%")
        self.update_progress(0, "开始处理视频...")
        
        # 启动视频处理线程
        video_thread = threading.Thread(target=self.process_video_thread, daemon=True)
        video_thread.start()
        logger.info("视频处理线程已启动")

    def process_video_thread(self):
        """在后台线程中处理视频"""
        logger.info(f"开始处理视频文件: {self.video_path}")
        try:
            # 提取特征和带关键点的帧
            self.update_progress(30, "正在提取特征...")
            features, annotated_frames = self.feature_extractor.extract_from_video(self.video_path)
            
            if features is None or features.size == 0:
                self.update_info("特征提取失败")
                self.result_label.config(text="特征提取失败")
                self.confidence_label.config(text="0%")
                self.update_progress(0, "特征提取失败")
                return
                
            # 显示视频预览
            if annotated_frames:
                self.update_progress(40, "显示视频预览...")
                # 显示第一帧
                self.display_annotated_frame(annotated_frames[0])
                
                # 显示所有帧（带关键点）
                for frame in annotated_frames:
                    self.display_annotated_frame(frame)
                    time.sleep(0.05)  # 控制播放速度
                    if not self.processing_file:  # 如果用户取消了处理
                        break
                
            self.update_progress(60, "正在执行识别...")
            
            # 执行识别
            predicted_text, confidence = self.recognizer.predict(features)
            
            # 更新结果
            self.result_label.config(text=predicted_text)
            self.confidence_label.config(text=f"{confidence*100:.1f}%")
            self.update_info(f"视频处理完成: {predicted_text} ({confidence*100:.1f}%)")
            self.update_progress(100, "处理完成")
            
            logger.info(f"视频处理完成, 结果: {predicted_text} 置信度: {confidence:.4f}")
                
        except Exception as e:
            error_msg = f"视频处理错误: {str(e)}"
            self.update_info(error_msg)
            self.result_label.config(text="处理错误")
            self.confidence_label.config(text="0%")
            self.update_progress(0, "处理失败")
            logger.exception(error_msg)
        finally:
            self.processing_file = False
            self.file_button.config(state=tk.NORMAL)
            self.process_button.config(state=tk.NORMAL)
            logger.info("视频处理完成")

    def display_annotated_frame(self, frame):
        """显示带关键点的帧"""
        if frame is None:
            return
            
        try:
            # 调整尺寸
            display_frame = cv2.resize(frame, (self.preview_width, self.preview_height))
            
            # 转换为RGB并创建图像
            rgb_frame = cv2.cvtColor(display_frame, cv2.COLOR_BGR2RGB)
            image = Image.fromarray(rgb_frame)
            photo = ImageTk.PhotoImage(image=image)
            
            # 更新预览
            self.preview_label.config(image=photo)
            self.preview_label.image = photo
            self.root.update()  # 强制更新UI
        except Exception as e:
            logger.error(f"显示帧时出错: {str(e)}")

    def start_camera(self):
        """启动摄像头"""
        logger.info("尝试启动摄像头...")
        if self.is_camera_running or self.processing_file:
            return
            
        self.update_info("正在启动摄像头...")
        self.cap = self.create_camera_capture()
        
        if self.cap and self.cap.isOpened():
            self.is_camera_running = True
            self.start_button.config(state=tk.DISABLED)
            self.stop_button.config(state=tk.NORMAL)
            self.record_button.config(state=tk.NORMAL)
            self.update_info("摄像头已启动")
            logger.info("摄像头启动成功")
            
            # 启动摄像头线程
            self.camera_thread = threading.Thread(target=self.update_frame, daemon=True)
            self.camera_thread.start()
            logger.info("摄像头帧更新线程已启动")
        else:
            self.update_info("无法启动摄像头，请检查连接")
            logger.error("无法启动摄像头")

    def create_camera_capture(self):
        """创建摄像头捕获对象"""
        logger.info("尝试打开摄像头设备...")
        
        # 尝试所有可能的设备路径
        for device in CAMERA_DEVICES:
            if os.path.exists(device):
                try:
                    logger.debug(f"尝试打开设备: {device}")
                    cap = cv2.VideoCapture(device)
                    if cap.isOpened():
                        # 尝试读取一帧以确认摄像头可用
                        ret, frame = cap.read()
                        if ret:
                            logger.info(f"摄像头设备 {device} 打开成功")
                            return cap
                        else:
                            cap.release()
                            logger.warning(f"设备 {极光device} 打开但无法读取帧")
                    else:
                        cap.release()
                        logger.warning(f"设备 {device} 打开失败")
                except Exception as e:
                    logger.error(f"打开设备 {device} 出错: {str(e)}")
        
        # 尝试索引方式
        logger.info("尝试通过索引打开摄像头...")
        for i in range(5):  # 尝试更多索引
            try:
                logger.debug(f"尝试打开索引: {i}")
                cap = cv2.VideoCapture(i)
                if cap.isOpened():
                    # 尝试读取一帧
                    ret, frame = cap.read()
                    if ret:
                        logger.info(f"摄像头索引 {i} 打开成功")
                        return cap
                    else:
                        cap.release()
                        logger.warning(f"索引 {i} 打开但无法读取帧")
                else:
                    cap.release()
                    logger.warning(f"索引 {i} 打开失败")
            except Exception as e:
                logger.error(f"打开索引 {i} 出错: {str(e)}")
        
        logger.error("所有摄像头尝试均失败")
        return None

    def stop_camera(self):
        """停止摄像头"""
        logger.info("停止摄像头...")
        if self.cap:
            self.cap.release()
            self.cap = None
            logger.info("摄像头资源已释放")
            
        self.is_camera_running = False
        self.is_recording = False
        
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.record_button.config(state=tk.DISABLED)
        self.stop_rec_button.config(state=极光tk.DISABLED)
        
        self.update_info("摄像头已停止")
        self.preview_label.config(image=None)
        logger.info("摄像头已完全停止")

    def start_recording(self):
        """开始录制识别"""
        logger.info("开始录制识别...")
        if not self.is_camera_running:
            logger.warning("摄像头未运行，无法开始识别")
            return
            
        self.is_recording = True
        self.recording_frames = []
        
        self.record_button.config(state=tk.DISABLED)
        self.stop_rec_button.config(state=tk.NORMAL)
        
        self.update_info(f"开始识别...将在{self.capture_duration}秒后自动分析")
        self.result_label.config(text="准备识别...")
        self.confidence_label.config(text="0%")
        self.update_progress(0, "准备录制...")
        
        # 启动识别倒计时
        self.recording_thread = threading.Thread(target=self.record_and_process, daemon=True)
        self.recording_thread.start()
        logger.info("识别状态已激活")

    def record_and_process(self):
        """录制并处理手语视频"""
        start_time = time.time()
        duration = self.capture_duration
        
        # 显示倒计时
        while time.time() - start_time < duration and self.is_recording:
            remaining = max(0, duration - (time.time() - start_time))
            self.update_info(f"录制中...剩余{remaining:.1f}秒")
            progress = min(100, int((time.time() - start_time) / duration * 100))
            self.update_progress(progress, "录制中...")
            time.sleep(0.1)
        
        if not self.is_recording:
            logger.info("识别被用户取消")
            return
            
        # 停止录制
        self.stop_recording()
        
        # 执行识别
        self.update_info("正在提取特征...")
        self.update_progress(30, "提取特征中...")
        
        # 提取特征
        features, _ = self.feature_extractor.extract_from_frames(self.recording_frames)
        if features is None or features.size == 0:
            self.update_info("特征提取失败")
            self.result_label.config(text="特征提取失败")
            self.confidence_label.config(text="0%")
            self.update_progress(0, "特征提取失败")
            return
            
        self.update_info("正在执行识别...")
        self.update_progress(60, "识别中...")
        
        # 执行识别
        predicted_text, confidence = self.recognizer.predict(features)
        
        # 更新结果
        self.result_label.config(text=predicted_text)
        self.confidence_label.config(text=f"{confidence*100:.1f}%")
        self.update_info(f"识别完成: {predicted_text} ({confidence*100:.1f}%)")
        self.update_progress(100, "识别完成")
        
        logger.info(f"识别完成, 结果: {predicted_text} 置信度: {confidence:.4f}")

    def stop_recording(self):
        """停止录制"""
        logger.info("停止录制识别")
        self.is_recording = False
        self.record_button.config(state=tk.NORMAL)
        self.stop_rec_button.config(state=tk.DISABLED)
        self.update_info("已停止录制")
        logger.info("识别状态已停止")

    def update_frame(self):
        """更新摄像头画面并显示手部关键点"""
        last_time = time.time()
        frame_count = 0
        logger.info("开始更新摄像头帧")
        
        # 初始化MediaPipe用于实时显示
        mp_hands = mp.solutions.hands
        hands = mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )
        mp_drawing = mp.solutions.drawing_utils
        mp_drawing_styles = mp.solutions.drawing_styles
        
        while self.is_camera_running:
            try:
                ret, frame = self.cap.read()
                if not ret:
                    self.update_info("摄像头读取错误")
                    logger.warning("摄像头读取帧失败")
                    time.sleep(0.1)
                    continue
                
                # 计算FPS
                frame_count += 1
                current_time = time.time()
                if current_time - last_time >= 1.0:
                    self.fps = frame_count
                    frame_count = 0
                    last_time = current_time
                    self.fps_label.config(text=f"FPS: {self.fps}")
                    logger.debug(f"当前FPS: {self.fps}")
                
                # 保存帧用于识别
                if self.is_recording:
                    self.recording_frames.append(frame.copy())
                
                # 处理帧 - 检测手部关键点
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                results = hands.process(rgb_frame)
                
                # 绘制关键点
                annotated_frame = frame.copy()
                if results.multi_hand_landmarks:
                    for hand_landmarks in results.multi_hand_landmarks:
                        mp_drawing.draw_landmarks(
                            annotated_frame,
                            hand_landmarks,
                            mp_hands.HAND_CONNECTIONS,
                            mp_drawing_styles.get_default_hand_landmarks_style(),
                            mp_drawing_styles.get_default_hand_connections_style())
                
                # 调整尺寸并显示
                display_frame = cv2.resize(annotated_frame, (self.preview_width, self.preview_height))
                
                # 转换为RGB并创建图像
                rgb_frame = cv2.cvtColor(display_frame, cv2.COLOR_BGR2RGB)
                image = Image.fromarray(rgb_frame)
                photo = ImageTk.PhotoImage(image=image)
                
                # 更新预览
                self.preview_label.config(image=photo)
                self.preview_label.image = photo
                
                # 避免过高CPU占用
                time.sleep(0.03)  # 大约30FPS
            except Exception as e:
                logger.error(f"更新摄像头帧时出错: {str(e)}", exc_info=True)
                time.sleep(0.5)
        
        hands.close()
        logger.info("摄像头帧更新线程已停止")

    def create_widgets(self):
        """创建紧凑的UI组件"""
        logger.info("创建UI组件...")
        # 主框架
        main_frame = tk.Frame(self.root, bg=BACKGROUND_COLOR)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 顶部区域 - 预览和控制
        top_frame = tk.Frame(main_frame, bg=BACKGROUND_COLOR)
        top_frame.pack(fill=tk.BOTH, expand=True)
        
        # 左侧 - 预览区域
        preview_frame = tk.LabelFrame(top_frame, text="预览", 
                                    fg=TEXT_COLOR, bg=BACKGROUND_COLOR, 
                                    font=self.config.title_font)
        preview_frame.pack(fill=tk.BOTH, expand=True, side=tk.LEFT, padx=(0, 10))
        
        self.preview_label = tk.Label(preview_frame, bg="black")
        self.preview_label.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # 右侧 - 控制区域
        control_frame = tk.Frame(top_frame, bg=BACKGROUND_COLOR, width=200)
        control_frame.pack(fill=tk.Y, side=tk.RIGHT)
        
        # 模式选择标签
        mode_label = tk.Label(control_frame, text="模式选择", fg=TEXT_COLOR, 
                             bg=BACKGROUND_COLOR, font=self.config.title_font)
        mode_label.pack(anchor=tk.W, pady=(0, 5))
        
        # 模式选择按钮
        self.mode_var = tk.StringVar(value="camera")
        
        camera_mode = tk.Radiobutton(control_frame, text="摄像头模式", variable=self.mode_var, 
                                   value="camera", bg=BACKGROUND_COLOR, fg=TEXT_COLOR,
                                   selectcolor=BACKGROUND_COLOR)
        camera_mode.pack(anchor=tk.W, padx=5, pady=2)
        
        file_mode = tk.Radiobutton(control_frame, text="文件模式", variable=self.mode_var, 
                                 value="file", bg=BACKGROUND_COLOR, fg=TEXT_COLOR,
                                 selectcolor=BACKGROUND_COLOR)
        file_mode.pack(anchor=tk.W, padx=5, pady=2)
        
        # 摄像头控制按钮
        self.start_button = tk.Button(control_frame, text="启动摄像头", 
                                    command=self.start_camera,
                                    font=self.config.ui_font, 
                                    bg=PRIMARY_COLOR, fg=TEXT_COLOR,
                                    width=self.config.button_width)
        self.start_button.pack(pady=5)
        
        self.stop_button = tk.Button(control_frame, text="停止摄像头", 
                                   command=self.stop_camera,
                                   font=self.config.ui_font, 
                                   bg=ACCENT_COLOR, fg=TEXT_COLOR,
                                   width=self.config.button_width, state=tk.DISABLED)
        self.stop_button.pack(pady=5)
        
        # 识别控制按钮
        self.record_button = tk.Button(control_frame, text="开始识别", 
                                      command=self.start_recording,
                                      font=self.config.ui_font, 
                                      bg=SECONDARY_COLOR, fg=TEXT_COLOR,
                                      width=self.config.button_width, state=tk.DISABLED)
        self.record_button.pack(pady=5)
        
        self.stop_rec_button = tk.Button(control_frame, text="停止识别", 
                                       command=self.stop_recording,
                                       font=self.config.ui_font, 
                                       bg=ACCENT_COLOR, fg=TEXT_COLOR,
                                       width=self.config.button_width, state=tk.DISABLED)
        self.stop_rec_button.pack(pady=5)
        
        # 设置区域
        settings_frame = tk.LabelFrame(control_frame, text="参数设置", 
                                      fg=TEXT_COLOR, bg=BACKGROUND_COLOR, 
                                      font=self.config.title_font)
        settings_frame.pack(fill=tk.X, pady=(10, 0))
        
        tk.Label(settings_frame, text="识别时长(秒):", fg=TEXT_COLOR, 
                bg=BACKGROUND_COLOR, font=self.config.ui_font).pack(anchor='w', padx=5)
        
        self.duration_var = tk.IntVar(value=self.capture_duration)
        duration_slider = Scale(settings_frame, from_=1, to=30, 
                               orient=tk.HORIZONTAL, variable=self.duration_var,
                               length=150, showvalue=True, 
                               bg=BACKGROUND_COLOR, fg=TEXT_COLOR,
                               command=self.update_duration)
        duration_slider.pack(padx=5, pady=5)
        
        # 文件选择按钮
        self.file_button = tk.Button(settings_frame, text="选择视频文件", 
                                   command=self.select_video_file,
                                   font=self.config.ui_font, 
                                   bg=PRIMARY_COLOR, fg=TEXT_COLOR,
                                   width=self.config.button_width)
        self.file_button.pack(pady=5)
        
        # 处理视频按钮
        self.process_button = tk.Button(settings_frame, text="处理视频文件", 
                                      command=self.process_video_file,
                                      font=self.config.ui_font, 
                                      bg=SECONDARY_COLOR, fg=TEXT_COLOR,
                                      width=self.config.button_width, state=tk.DISABLED)
        self.process_button.pack(pady=5)
        
        # 底部区域 - 结果和状态
        bottom_frame = tk.Frame(main_frame, bg=BACKGROUND_COLOR)
        bottom_frame.pack(fill=tk.X, pady=(10, 0))
        
        # 结果面板
        result_frame = tk.Frame(bottom_frame, bg="#1a252f")
        result_frame.pack(fill=tk.X)
        
        tk.Label(result_frame, text="识别结果:", 
                font=self.config.title_font, 
                fg=TEXT_COLOR, bg="#1a252f").pack(side=tk.LEFT, padx=10, pady=5)
        
        self.result_label = tk.Label(result_frame, text="", 
                                   font=self.config.result_font, 
                                   fg=SECONDARY_COLOR, bg="#1a252f")
        self.result_label.pack(side=tk.LEFT, padx=5, pady=5)
        
        # 置信度显示
        tk.Label(result_frame, text="置信度:", 
                font=self.config.title_font, 
                f极光=TEXT_COLOR, bg="#1a252f").pack(side=tk.LEFT, padx=10, pady=5)
        
        self.confidence_label = tk.Label(result_frame, text="0%", 
                                      font=self.config.result_font, 
                                      fg=SECONDARY_COLOR, bg="#1a252f")
        self.confidence_label.pack(side=tk.LEFT, padx=5, pady=5)
        
        # 进度条区域
        progress_frame = tk.Frame(bottom_frame, bg="#1a252f")
        progress_frame.pack(fill=tk.X, pady=(5, 0))
        
        self.progress_var = tk.DoubleVar(value=0)
        self.progress_bar = ttk.Progressbar(progress_frame, variable=self.progress_var,
                                           maximum=100, length=400)
        self.progress_bar.pack(fill=tk.X, padx=10, pady=5)
        self.progress_label = tk.Label(progress_frame, text="就绪", bg="#1a252f", 
                                     fg=TEXT_COLOR, font=self.config.ui_font)
        self.progress_label.pack(fill=tk.X, padx=10)
        
        # 状态栏
        status_frame = tk.Frame(bottom_frame, bg="#1a252f")
        status_frame.pack(fill=tk.X, pady=(5, 0))
        
        self.status_label = tk.Label(status_frame, text="就绪", anchor=tk.W, 
                                   font=self.config.ui_font, fg=TEXT_COLOR, bg="#1a252f")
        self.status_label.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=10)
        
        self.fps_label = tk.Label(status_frame, text="FPS: --", anchor=tk.E, 
                                font=self.config.ui_font, fg=TEXT_COLOR, bg="#1a252f")
        self.fps_label.pack(side=tk.RIGHT, padx=10)
        
        # 退出按钮
        exit_button = tk.Button(status_frame, text="退出", command=self.close, 
                font=self.config.ui_font, bg=ACCENT_COLOR, fg=TEXT_COLOR, width=8)
        exit_button.pack(side=tk.RIGHT, padx=5)
        
        logger.info("UI组件创建完成")

    def close(self):
        """关闭应用程序"""
        logger.info("关闭应用程序...")
        self.is_camera_running = False
        self.is_recording = False
        self.processing_file = False
        
        if self.cap:
            self.cap.release()
            logger.info("摄像头资源已释放")
            
        if self.recognizer:
            self.recognizer.release()
            logger.info("RKNN资源已释放")
            
        self.root.destroy()
        logger.info("应用程序已关闭")


# 主函数
def main():
    print("===== RK3588手语识别系统启动 =====")
    print(f"模型路径: {MODEL_PATH}")
    print(f"语料库路径: {CORPUS_PATH}")
    
    try:
        root = tk.Tk()
        app = SignLanguageApp(root)
        root.protocol("WM_DELETE_WINDOW", app.close)
        root.mainloop()
    except Exception as e:
        logging.exception("程序发生未处理的异常")
        print(f"程序崩溃: {str(e)}")

if __name__ == '__main__':
    main()