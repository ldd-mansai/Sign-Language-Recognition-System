

import torch
import torch.nn as nn


class EnsembleModel(nn.Module):
    def __init__(self, models, weights=None):
        super(EnsembleModel, self).__init__()
        self.models = nn.ModuleList(models)

        if weights is None:
            self.weights = torch.ones(len(models)) / len(models)
        else:
            self.weights = torch.tensor(weights) / sum(weights)

    def forward(self, x):
        outputs = []
        for model in self.models:
            outputs.append(model(x))

        # 加权平均
        ensemble_output = torch.zeros_like(outputs[0])
        for i, output in enumerate(outputs):
            ensemble_output += output * self.weights[i]

        return ensemble_output
